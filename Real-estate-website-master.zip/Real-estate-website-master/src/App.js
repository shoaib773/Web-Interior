import './App.css'; // Ensure App.css is in the right folder
import Pages from './components/pages/Pages.jsx'; // Ensure the path to Pages.js is correct

function App() {
  return (   
      <Pages />  /* Render the Pages component */
  
  );
}

export default App;