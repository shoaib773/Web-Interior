Project Demo : https://funny-daffodil-350bc9.netlify.app/  

Project Video  : https://www.youtube.com/watch?v=iqfxu4s6i4Y&ab_channel=GorkCoder 

![screencapture-funny-daffodil-350bc9-netlify-app-2023-06-18-13_10_37](https://github.com/sunil9813/Real-estate-website/assets/67497228/011837d1-0937-40cd-8ea2-aa83aefaf649)
